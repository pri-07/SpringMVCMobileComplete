package com.cg.springmvcone.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcone.dto.Mobile;
import com.cg.springmvcone.service.IMobileService;

@Controller
public class MobileController {
	
	@Autowired
	IMobileService mobileservice;
	 
	@RequestMapping(value="/home") //mapping
	public String getAllMobile(@ModelAttribute("my") Mobile mob,Map<String,Object> model)
	{
		List<String> myList=new ArrayList<>();
		myList.add("Android");
		myList.add("iOS");
		myList.add("Windows");
		
		model.put("cato", myList);
		return "AddMobile";
	
	}
	
	@RequestMapping(value="adddata",method=RequestMethod.POST) //mapping
	public String addMobileData(@ModelAttribute("my") Mobile mobile)
	{
		mobileservice.addMobile(mobile);
	//	System.out.println(mobile.getMobId()+" "+mobile.getMobName()+" "+mobile.getMobPrice()+" "+mobile.getMobCategory()+" "+mobile.getMobOnline());
		return "success";
		
	}
	
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public ModelAndView showAllMobileData()
	{
		List<Mobile> allMobile=mobileservice.showAllMobile();
		//System.out.println(allMobile); to check if values appear on console
		return new ModelAndView("mobileshow", "data", allMobile);
		
	}
	
	@RequestMapping(value="searchmobile",method=RequestMethod.GET)
	public String searchData(@ModelAttribute("yy") Mobile mob)
	{
		return "searchmobile";
	}
	
	@RequestMapping(value="mobilesearch",method=RequestMethod.POST)
	public ModelAndView dataSearch(@ModelAttribute("yy") Mobile mob)
	{
		
		Mobile mobSearch=mobileservice.searchMobile(mob.getMobId());
		//System.out.println(mobSearch);
		return new ModelAndView("showsearch","temp",mobSearch);
	}
	
	//delete
	@RequestMapping(value="deletemobile",method=RequestMethod.GET)
	public String deleteData(@ModelAttribute("dd") Mobile mob)
	{
		return "delete";
	}
	
	@RequestMapping(value="deletemobilereturn",method=RequestMethod.POST)
	public String mobileDelete(@ModelAttribute("dd") Mobile mob)
	{
		mobileservice.deleteMobile(mob.getMobId());
		return "deletesuccess";
		
	}
	
	
	//update
	@RequestMapping(value="updatemobile",method=RequestMethod.GET)
	public String updateInput(@ModelAttribute("uu") Mobile mob)
	{
		
		return "entryupdate";
		
	}
	
	@RequestMapping(value="mobileupdate",method=RequestMethod.POST)
	public ModelAndView updateOutput(@ModelAttribute("uu") Mobile mob)
	{
		Mobile mobile=mobileservice.updateMobile(mob);
		mobile.getMobCategory();
		mobile.getMobOnline();
		//System.out.println(mobile);
		return new ModelAndView("mobupdateoutput", "mobup", mobile);
		
	}
}
