package com.cg.springmvcone.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MOBILEONEDATA")
public class Mobile {
	
	@Id
	@Column(name="MOB_ID")
	Integer mobId;
	
	@Column(name="MOB_NAME")
	String mobName;
	
	@Column(name="MOB_PRICE")
	Double mobPrice;
	
	@Column(name="MOB_CATO")
	String mobCategory;
	
	@Column(name="MOB_ONLINE")
	String mobOnline;
	
	

	//default constructor
	public Mobile() {
	
	}
	
	//getter setter
	public Integer getMobId() {
		return mobId;
	}
	public void setMobId(Integer mobId) {
		this.mobId = mobId;
	}
	public String getMobName() {
		return mobName;
	}
	public void setMobName(String mobName) {
		this.mobName = mobName;
	}
	public Double getMobPrice() {
		return mobPrice;
	}
	public void setMobPrice(Double mobPrice) {
		this.mobPrice = mobPrice;
	}
	public String getMobCategory() {
		return mobCategory;
	}
	public void setMobCategory(String mobCategory) {
		this.mobCategory = mobCategory;
	}
	public String getMobOnline() {
		return mobOnline;
	}

	public void setMobOnline(String mobOnline) {
		this.mobOnline = mobOnline;
	}

	//To String
	@Override
	public String toString() {
		return "Mobile [mobId=" + mobId + ", mobName=" + mobName
				+ ", mobPrice=" + mobPrice + ", mobCategory=" + mobCategory
				+ ", mobOnline=" + mobOnline + "]";
	}

	public Mobile(Integer mobId, String mobName, Double mobPrice,
			String mobCategory, String mobOnline) {
		super();
		this.mobId = mobId;
		this.mobName = mobName;
		this.mobPrice = mobPrice;
		this.mobCategory = mobCategory;
		this.mobOnline = mobOnline;
	}

	
	
}
