package com.cg.springmvcone.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.springmvcone.dto.Mobile;

@Repository("mobiledao")
public class MobileDAOImpl implements IMobileDAO {

	@PersistenceContext
	EntityManager em;

	@Override
	public void addMobile(Mobile mobile) {
		// TODO Auto-generated method stub
		em.persist(mobile);
		em.flush();
	}

	@Override
	public List<Mobile> showAllMobile() {
		// TODO Auto-generated method stub
		Query query=em.createQuery("FROM Mobile");
		List<Mobile> myAll=query.getResultList();
		return myAll;
	}

	@Override
	public void deleteMobile(int mobId) {
		// TODO Auto-generated method stub
		Query queryDelete=em.createQuery("delete FROM Mobile where mobId=:mobdelete");
		queryDelete.setParameter("mobdelete", mobId);
		queryDelete.executeUpdate();
		
	}

	@Override
	public Mobile searchMobile(int mobId) {
		// TODO Auto-generated method stub
		Query querySearch=em.createQuery("FROM Mobile where mobId=:mobdata");
		querySearch.setParameter("mobdata", mobId);
		Mobile mob=(Mobile) querySearch.getSingleResult();
		return mob;
	}

	@Override
	public Mobile updateMobile(Mobile mob) {
		// TODO Auto-generated method stub
		Query queryUpdate=em.createQuery("update Mobile set mobName=:newmobname,mobPrice=:newmobprice,mobCategory=:newmobcat,mobOnline=:newmobon where mobId=:mobupdate");
		queryUpdate.setParameter("mobupdate", mob.getMobId());
		queryUpdate.setParameter("newmobname", mob.getMobName());
		queryUpdate.setParameter("newmobprice", mob.getMobPrice());
		queryUpdate.setParameter("newmobcat", mob.getMobCategory());
		queryUpdate.setParameter("newmobon", mob.getMobOnline());
		queryUpdate.executeUpdate();
		return mob;
	}

}
